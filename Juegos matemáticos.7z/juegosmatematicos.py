# Proyecto número 2
"""
Dos juegos: Cálculo matemático y conversión binaria
Este es el programa principal.
"""

from usrclases import  usrClase
from gameclasses import BinaryGame, MathGame

def printInstructions(instruction):
    print(instruction)


try:
    mathInstructions = "En este juego, se le hará una pregunta matemática, \ncada respuesta correcta le dará un punto. \nNo se reducen puntos por respuesta equivocadas"
    binaryInstructions = "En este juego se le presentara un número en base 10. \nSu tarea es convertir este número a base 2. \ncada respuesta correcta le dará un punto. \nNo se reducen puntos por respuesta equivocadas"
    bg = BinaryGame()
    mg = MathGame()
    usr = usrClase()
    userName = input("Ingrese su nombre ")
    userScore = int(usr.getUserScore(userName))
    if userScore == -1:
        userScore = 0
        newUser = True
    else:
        newUser = False
    
    print("\n¡Hola %s !,¡Bienvenido al juego!" %(userName))
    print("Tu puntaje actual es %d." %(userScore))
  
    userChoice = "0"
    while userChoice != "-1":
        userGame = input("\n¿Juego matematico(1) o juego Binario(2)? ")
        while userGame != "1" and userGame!= "2":
            print("\nSu respuesta debe ser 1 o 2")
            userGame = input("\n¿Juego matematico(1) o juego Binario(2)? ")
            
        numPrompt = input("\n¿Cuántas preguntas quieres por juego (1 a 10)? ")
        while True:
            try:
                num = int(numPrompt)
                break
            except:
                print("No ha ingresado un número válido, por favor inténtelo nuevamente")
                numPrompt = input("\n¿Cuántas preguntas quieres por juego (1 a 10) ?")
        
        if userGame == "1":
            mg.noOfQuestions = num
            printInstructions(mathInstructions)
            userScore = userScore + mg.generateQuestions()
        else:
            bg.noOfQuestions = num
            printInstructions(binaryInstructions)
            userScore = userScore + bg.generateQuestions()            
        
        print("\nSu puntaje actual es %d."%(userScore))
        userChoice = input("¿Desea continuar el juego?. Digite -1 para salir ")
    usr.upadateUserScore(newUser,userName,userScore)
except Exception as e:
    print("Un error ha ocurrido el programa se cerrará. El error es ", e)
    

















