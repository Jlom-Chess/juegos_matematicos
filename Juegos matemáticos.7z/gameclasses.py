# Proyecto número 2
"""
Dos juegos: Cálculo matemático y conversión binaria
Aquí se definirán las clases
Habráb tres clases: Game, MathGame y BinaryGame
"""

# Primera clase: Game
"""
La primera clase Game, será la clase padre o super clase de la cual se derivarán las otras
"""


class Game:
    def __init__(self, noOfQuestions=0):
        self._noOfQuestions = noOfQuestions

    @property
    def noOfQuestions(self):
        return self._noOfQuestions

    @noOfQuestions.setter
    def noOfQuestions(self, value):
        if value < 1:
            print("\nMínimo número de preguntas es 1. \nEl numero de preguntas será establecido en 1")
            value = 1
        elif value > 10:
            print("\nMáximomo número de preguntas es 10. \nEl numero de preguntas será establecido en 10")
            value = 10
        self._noOfQuestions = value


class BinaryGame(Game):
    def generateQuestions(self):
        from random import randint
        score = 0
        for i in range(self.noOfQuestions):
            base10 = randint(1, 100)
            print("\nConvierta el siguiente número a binario", base10)
            userResult = input("\nIngrese su respuesta ")
            while True:
                try:
                    answer = int(userResult, base=2)
                    if answer == base10:
                        score += 1
                        print("\n¡Respuesta correcta!")
                        break
                    else:
                        print("\Respuesta incorrecta. La respuesta incorrecta es {:b}.".format(base10))
                        break
                except:
                    print("\nUsted no ha ingresado un número binario, \nPor favor vuelva a ingresar su respueta")
                    userResult = input("\nIngrese su nueva respuesta ")
        return score


class MathGame(Game):
    def generateQuestions(self):
        from random import randint
        score = 0
        operandList = [0, 0, 0, 0, 0]
        operatorList = ["", "", "", ""]
        operatorDict = {1: "+", 2: "-", 3: "*", 4: "/", 5: "**"}
        for i in range(self.noOfQuestions):
            while True:
                for i in range(len(operandList)):
                    operandList[i] = randint(1, 9)

                operatorAnterior = ""
                for i in range(len(operatorList)):
                    operatorList[i] = operatorDict[randint(1, 5)]
                    if operatorList[i] == "**" and operatorAnterior == "**":
                        operatorList[i] = operatorDict[randint(1, 4)]
                        operatorAnterior = operatorList[i]

                # Genera la expresión matemática
                openBracket = randint(0, 3)
                closeBracket = randint(openBracket + 1, 4)
                for i in range(0, 5):
                    if i == 0:
                        if openBracket == 0:
                            questionString = "(" + str(operandList[i])
                        else:
                            questionString = str(operandList[i])
                    else:
                        if i == openBracket:
                            questionString = questionString + operatorList[i - 1] + "(" + str(operandList[i])
                        elif i == closeBracket:
                            questionString = questionString + operatorList[i - 1] + str(operandList[i]) + ")"
                        else:
                            questionString = questionString + operatorList[i - 1] + str(operandList[i])

                newResult = round(eval(questionString), 2)
                if newResult >= -50000 and newResult <= 50000:
                    break
            questionString = questionString.replace("**", "^")

            print("\n" + questionString)
            respuesta = input("Por favor ingrese su respuesta (redondeado a 2 decimales) ")
            while True:
                try:
                    if float(respuesta) == newResult:
                        print("\n" + "¡Respuesta correcta!, ha ganado un punto")
                        score += 1
                        break
                    else:
                        print("\n" + "Respuesta incorrecta, la respuesta correcta es ", newResult)
                        break
                except Exception as e:
                    print("Usted no ingresó un número, por favor intente otra vez", e)
                    respuesta = input("Por favor ingrese su respuesta ")
        return score
