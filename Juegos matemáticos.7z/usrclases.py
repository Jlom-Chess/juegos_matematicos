# Proyecto número 2
"""
Aquí se definen las clases de los juegos: Cálculo matemático y conversión binaria.
"""
# Se requieren las funciones rmove y rename del módulo os
from os import remove, rename

class usrClase: 
    def getUserScore(self,userName):
        try:
            scores = open("userScores.txt", "r")
            for line in scores:
                listaUser=line.split(",")
                if listaUser[0] == userName:
                    scores.close()
                    return listaUser[1]
                scores.close()
                return "-1"
        except IOError:
            print("\nArchivo userScores.txt no se encontró. Un nuevo archivo será creado")
            scores = open ("userScores.txt", "w")
            scores.close()
            return "-1"


    def upadateUserScore(self,newUser,username,score):
        if newUser:
            scores = open("userScores.txt", "a")
            scores.write("\n"+username + "," + str(score))
            scores.close()
        else:
            scores = open("userScores.txt", "r")
            scorestmp = open("userScores.tmp", "w")
            for line in scores:
                listaUser=line.split(",")
                if listaUser[0] == username:
                    line = username + "," + str(score) + "\n" # Al crearse una línea debe incluirse una "nueva línea"
                scorestmp.write(line) # si viene directo del otro archivo ya tiene su "neva línea"
            scores.close()
            scorestmp.close()
            remove("userScores.txt")
            rename("userScores.tmp","userScores.txt")
